﻿namespace FormsCasa
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtComando = new TextBox();
            label1 = new Label();
            txtResposta = new TextBox();
            label2 = new Label();
            btnEnviar = new Button();
            btnClean = new Button();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            SuspendLayout();
            // 
            // txtComando
            // 
            txtComando.Location = new Point(342, 70);
            txtComando.MaximumSize = new Size(100, 100);
            txtComando.MinimumSize = new Size(0, 10);
            txtComando.Name = "txtComando";
            txtComando.Size = new Size(68, 23);
            txtComando.TabIndex = 0;
            txtComando.TextChanged += txtComando_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(301, 32);
            label1.Name = "label1";
            label1.Size = new Size(168, 20);
            label1.TabIndex = 1;
            label1.Text = "Ative os sensores [1 a 5]";
            // 
            // txtResposta
            // 
            txtResposta.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtResposta.Location = new Point(60, 233);
            txtResposta.Multiline = true;
            txtResposta.Name = "txtResposta";
            txtResposta.ReadOnly = true;
            txtResposta.ScrollBars = ScrollBars.Vertical;
            txtResposta.Size = new Size(409, 205);
            txtResposta.TabIndex = 2;
            txtResposta.Text = "\r\n";
            txtResposta.TextChanged += txtResposta_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(60, 206);
            label2.Name = "label2";
            label2.Size = new Size(124, 15);
            label2.TabIndex = 3;
            label2.Text = "RESPOSTA DO SERVER";
            // 
            // btnEnviar
            // 
            btnEnviar.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEnviar.Location = new Point(88, 123);
            btnEnviar.Name = "btnEnviar";
            btnEnviar.Size = new Size(126, 61);
            btnEnviar.TabIndex = 4;
            btnEnviar.Text = "ENVIAR";
            btnEnviar.UseVisualStyleBackColor = true;
            btnEnviar.Click += button1_Click;
            // 
            // btnClean
            // 
            btnClean.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnClean.Location = new Point(558, 123);
            btnClean.Name = "btnClean";
            btnClean.Size = new Size(117, 61);
            btnClean.TabIndex = 5;
            btnClean.Text = "limpar tela";
            btnClean.UseVisualStyleBackColor = true;
            btnClean.Click += button2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(246, 113);
            label3.Name = "label3";
            label3.Size = new Size(283, 20);
            label3.TabIndex = 6;
            label3.Text = "Digite [6] para visualizar o consumo total";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(301, 154);
            label4.Name = "label4";
            label4.Size = new Size(178, 20);
            label4.TabIndex = 7;
            label4.Text = "[0] para Resetar consumo";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(516, 275);
            label5.Name = "label5";
            label5.Size = new Size(232, 126);
            label5.TabIndex = 8;
            label5.Text = "Sensor[1 e  2] Quarto1/Quarto2\r\nSensor[3] Sala\r\nSensor [4] Cozinha\r\nSensor[5] Piscina\r\n \r\n\r\n";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(812, 477);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(btnClean);
            Controls.Add(btnEnviar);
            Controls.Add(label2);
            Controls.Add(txtResposta);
            Controls.Add(label1);
            Controls.Add(txtComando);
            Name = "Form1";
            Text = "Central de comando ";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private TextBox txtResposta;
        private Label label2;
        private Button btnEnviar;
        public TextBox txtComando;
        private Button btnClean;
        private Label label3;
        private Label label4;
        private Label label5;
    }
}
