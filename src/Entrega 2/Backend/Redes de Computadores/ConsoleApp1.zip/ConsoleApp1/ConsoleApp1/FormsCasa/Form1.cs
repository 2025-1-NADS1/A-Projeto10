using System.IO;
using System.Net.Sockets;
using System.Text;

namespace FormsCasa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtComando_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ipServidor = "127.0.0.1"; // IP do servidor
            int porta = 5000; // Porta do servidor

            try
            {


                while (true)
                    using (TcpClient cliente = new TcpClient())
                    {

                        {
                            string input = txtComando.Text;
                            cliente.Connect(ipServidor, porta);
                            NetworkStream stream = cliente.GetStream();

                            if (int.TryParse(input, out int sensorId))
                            {
                                if (sensorId == 0)
                                {
                                    txtResposta.Text += "Resetando o consumo\r\n";
                                    string mensagem = sensorId.ToString();
                                    byte[] dados = Encoding.ASCII.GetBytes(mensagem);
                                    stream.Write(dados, 0, dados.Length);
                                    break;
                                }
                                else if (sensorId >= 1 && sensorId <= 6)
                                {
                                    // Envia o comando ao servidor
                                    string mensagem = sensorId.ToString();
                                    byte[] dados = Encoding.ASCII.GetBytes(mensagem);
                                    stream.Write(dados, 0, dados.Length);

                                    // Opcional: receber resposta do servidor
                                    byte[] buffer = new byte[1024];
                                    int bytesLidos = stream.Read(buffer, 0, buffer.Length);
                                    string resposta = Encoding.ASCII.GetString(buffer, 0, bytesLidos);
                                  
                                    txtResposta.Text += ( resposta + "\r\n");
                                    break;
                                }
                                else
                                {
                                    txtResposta.Text += ("Por favor, insira um n�mero entre 1 e 5, ou 0 para sair.\r\n");
                                    break;
                                }
                            }
                            else
                            {
                                txtResposta.Text += ("Entrada inv�lida. Tente novamente.\r\n");
                                break;
                            }

                            stream.Close();
                            cliente.Close();
                        }



                    }
            }
            catch (Exception ex)
            {
                txtResposta.Text += ("Erro: " + ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtResposta.Text = "";

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtResposta_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
