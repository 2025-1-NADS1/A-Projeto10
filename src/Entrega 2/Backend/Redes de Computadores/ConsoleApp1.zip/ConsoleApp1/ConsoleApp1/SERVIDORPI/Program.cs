﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

class Servidor
{
    static bool servidorAtivo = true;
    static double consumoTotal = 0;
    static String ct = consumoTotal.ToString("F2");
    static double consumoReais = 0;
    static String cr = consumoReais.ToString("F2");
    static String gasto ;
    static void Main()
    {
        int porta = 5000;
        TcpListener servidor = new TcpListener(IPAddress.Any, porta);
        servidor.Start();
        Console.WriteLine("Servidor iniciado na porta " + porta);

        while (servidorAtivo)
        {
            Console.WriteLine("Aguardando conexão...");
            TcpClient cliente = servidor.AcceptTcpClient();
            NetworkStream stream = cliente.GetStream();
            Console.WriteLine("conectou");

            // Recebe o comando do cliente
            byte[] buffer = new byte[1024];
            int bytesLidos = stream.Read(buffer, 0, buffer.Length);
            string mensagemRecebida = Encoding.ASCII.GetString(buffer, 0, bytesLidos).Trim();
            Console.WriteLine(mensagemRecebida);
            // Tenta converter o comando para inteiro (ID)
            if (int.TryParse(mensagemRecebida, out int idSensor))
            {
                string resposta = "";
                double consumo = 0;

                switch (idSensor)
                {
                    case 1:
                    case 2:
                        consumo = 1.5;
                        resposta = $"Sensor {idSensor} ligado. Consumo gerado: {consumo} KWh.";
                        break;
                    case 3:
                        consumo = 0.05;
                        resposta = $"Sensor {idSensor} ligado. Consumo gerado: {consumo} KWh.";
                        break;
                    case 4:
                        consumo = 3;
                        resposta = $"Sensor {idSensor} ligado. Consumo gerado: {consumo} KWh.";
                        break;
                    case 5:
                        consumo = 7;
                        resposta = $"Sensor {idSensor} ligado. Consumo gerado: {consumo} KWh.";
                        break;
                    case 6: // case para exibir o consumo total
                        resposta = $"Consumo total acumulado: {ct} KWh. equivalente a: R${cr} ";
                        break;
                    case 0: // Case para resetar o consumo
                        consumoTotal = 0; 
                        consumoReais = 0;
                        ct = "0";
                        cr = "0";
                        resposta = "Sistema encerrado. Consumo total resetado.";
                        break;
                    default:
                        resposta = "ID inválido.";
                        break;
                }
                if (idSensor != 6 && idSensor != 0)
                {
                    consumoTotal += consumo;
                    consumoReais = consumoTotal * 0.50;
                    ct = consumoTotal.ToString("F2");
                    cr = consumoReais.ToString("F2");
                    gasto = consumoReais.ToString("N2");
                    Console.WriteLine($"Consumo Total: {consumoTotal}");
                    Console.WriteLine($"Tarifa aplicada: 0.50");
                    Console.WriteLine($"Consumo em Reais (calculado): {consumoTotal * 0.50}");
                    Console.WriteLine($"Valor enviado: {gasto}");


                }


                // Envia a resposta ao cliente
                byte[] respostaBytes = Encoding.ASCII.GetBytes(resposta);
                stream.Write(respostaBytes, 0, respostaBytes.Length);
            }
            else
            {
                string resposta = "Comando inválido.";
                byte[] respostaBytes = Encoding.ASCII.GetBytes(resposta);
                stream.Write(respostaBytes, 0, respostaBytes.Length);
            }

            stream.Close();
            cliente.Close();
        }
       
        Console.WriteLine("Servidor encerrado.");

    }
}
